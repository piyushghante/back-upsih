from solcx import install_solc, set_solc_version

# Install Solidity version 0.8.20
install_solc('0.8.20')

# Set Solidity version 0.8.20
set_solc_version('0.8.20')
